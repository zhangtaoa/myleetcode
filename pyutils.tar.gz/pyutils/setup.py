#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

author:     meng.xiang
date:       2018/6/29
description: setup files
"""

from setuptools import setup, find_packages

setup(
    name="pyutils",
    version="0.2.0",
    keywords=("pip", "utils", "common", "tools", "moji"),
    description="utils lib for python",
    long_description="utils lib for python",
    license="MIT Licence",

    url="http://gitlab.moji.com/python-team/pyutils",
    author="meng.xiang",
    author_email="meng.xiang@moji.com",

    packages=find_packages(),
    include_package_data=True,
    platforms="any",
    install_requires=[
        'oss2',
        'gevent',
        'coloredlogs',
        'requests',
        'safe_logger'
    ]
)
