# coding=utf-8

# Copyright (c) 2018 - <tao.zhang@moji.com>

"""
Author: tao.zhang
Create Date: 2019/3/1
@Software: PyCharm
descirption:
"""

from pyutils import time_utils


if __name__ == "__main__":
    print(time_utils.getfixedtime(format="%Y%m%d%H0000", fixhours=-8))
    print(time_utils.stringToTimestamp("2019-03-06 03:00:00", format='%Y-%m-%d %H:%M:%S.'))
