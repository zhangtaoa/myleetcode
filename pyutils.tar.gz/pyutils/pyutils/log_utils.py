#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
author:     haifeng.lv
date:       2016/5/16
descirption:自定制logger模块
"""
import logging
import logging.config
import os
import socket

import coloredlogs
from safe_logger import TimedRotatingFileHandlerSafe

from pyutils.common_utils import touch_dir


class LoggerUtils(object):
    """
    loggerName:Logger 标识。
    loggerFile:自定制log的存储路径。
    isPrint:是否在控制台显示，默认是不显示。
    """

    def __init__(self, logger_name, logger_file_name, logger_path=None, is_print=None, level=None):

        self.loggerName = logger_name

        if not logger_path:
            logger_path = '/opt/logs/'
        logger_file = os.path.join(logger_path, logger_file_name)
        touch_dir(os.path.dirname(logger_file))
        self.logger_file = logger_file
        self.level = level if level else logging.INFO
        self.isPrint = is_print
        self.host_name = socket.gethostname()

    def get_logger(self, fmt=None):
        if fmt is None:
            fmt = '%(process)d - %(asctime)s - %(levelname)s - ' + self.host_name + ' - %(filename)s:%(lineno)d - %(message)s'
        logger = logging.getLogger(self.loggerName)
        logger.setLevel(self.level)
        formatter = logging.Formatter(fmt)
        th = TimedRotatingFileHandlerSafe(
            filename=self.logger_file, when="midnight", backupCount=10,
            encoding='utf-8')
        th.setFormatter(formatter)
        logger.addHandler(th)
        if self.isPrint:
            coloredlogs.install(level=self.level, logger=logger, fmt=fmt)
        return logger


if __name__ == "__main__":
    moji = LoggerUtils("log1", "log1.log", logger_path='./', is_print=True, level=logging.DEBUG).get_logger()
    moji2 = LoggerUtils("log2", "log2.log", logger_path='./', is_print=True, level=logging.DEBUG).get_logger()
    # moji = LoggerUtils("log1", "../logs/log1.log", isPrint= True)
    moji.debug("debug 消息")
    moji.info("info 消息")
    moji.warning("warning 消息")
    moji2.error(u"error 消息")
    moji2.critical(u"critical 消息")
