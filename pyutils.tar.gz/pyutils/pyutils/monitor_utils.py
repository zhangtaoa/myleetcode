#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
author:     jihong.wang
date:       2017/8/21
descirption: 该模块实现了把告警内容以不同的方式（微信，短信，邮件）通知不同业务（数据中心，aqi，模式，短时）开发人员的目标。
标签依次如下：
    wdc: 15
    nowcast: 16
    moge:  17
    api: 18
"""
from __future__ import print_function

import datetime
import hashlib
import smtplib
import socket
import time
from email.header import Header
from email.mime.text import MIMEText

import requests


def send_wechat(msg, logger=None):
    """
        微信告警
    """
    monitor_domain, monitor_type = 'www.moji.com', '数据中心'
    monitor_dest, fault_time = socket.gethostname(), time.time()
    DRCT_SALT = 'ce041913f7e929050c0c1047e7f1b890'
    # token
    m = hashlib.md5()
    m.update(monitor_domain + monitor_dest + monitor_type + str(fault_time) + DRCT_SALT)
    token = m.hexdigest()

    # 参数
    payload = {'monitor_domain': monitor_domain,
               'monitor_dest': monitor_dest,
               'monitor_type': monitor_type,
               'fault_time': fault_time,
               'msg_status': 1,  # 消息类型：1 告警，2 恢复
               'msg': msg,  # 消息详情
               'token': token,
               'send_to_type': 3,  # 发送类型：1 发送给所有用户， 2 按部门发送， 3 按标签发送， 4 发送给单个用户
               'send_to_id': 15  # 发送ID：对应发送类型的ID，部门ID／标签ID／用户ID，
               }
    try:
        url = 'http://monitor.matrixback.com:8080/alert.php'
        requests.post(url, data=payload)
    except Exception as ex:
        if logger:
            logger.error("send wechat except")
            logger.exception(ex)
        else:
            print("send wechat except")
            print(ex)


def send_email(email_to, message, is_plain=True, logger=None):
    """
    subject对应公司的标题，emailto代表收件人，emailfrom代表发件人，message：邮件内容
    isplain代表是否送纯文本文件还是html邮件内容
    """
    mailUserName, mailPasswd = 'jihong.wang@moji.com', 'Wjh199133'  # 登录公司邮件服务器的用户和密码（可以是个人账号和密码）
    email_from, subject = 'jihong.wang@moji.com', "数据中心告警"
    smtpServer, smtpPort = 'smtp.partner.outlook.cn', 587  # 公司邮件服务器器默认地址和端口
    smtp, result = None, False
    try:
        smtp = smtplib.SMTP()
        smtp_connect = smtp.connect(host=smtpServer, port=smtpPort)
        # 220代表smtp连接服务器成功返回代码
        if smtp_connect and len(smtp_connect) and smtp_connect[0] == 220:
            smtp.starttls()
            is_logined = smtp.login(mailUserName, mailPasswd)
            # 235代表邮箱认证通过代码
            if is_logined and len(is_logined) and is_logined[0] == 235:
                if is_plain:
                    msg = MIMEText(socket.gethostname() + ':  ' + message, 'text', 'utf-8')
                else:
                    msg = MIMEText(socket.gethostname() + ':  ' + message, 'html', 'utf-8')
                msg['From'] = Header(email_from, 'utf-8')
                msg['Subject'] = Header(subject, 'utf-8')
                msg['To'] = ",".join(email_to)
                smtp.sendmail(email_from, email_to, msg.as_string())
                result = True
            else:
                if logger:
                    logger.error("smtp邮件服务器登录失败")
        else:
            if logger:
                logger.error("smtp邮件服务器连接失败")

    except Exception as e:
        if logger:
            logger.error("send mail except")
            logger.exception(e)
        else:
            print("send mail except")
            print(e)
    finally:
        if smtp is not None:
            smtp.quit()
    return result


def send_sms(phones, msg, logger=None):
    """
        短信告警
    """
    try:
        url = "http://u.mojichina.com/mojiuc/sms/send"

        params = {"partnerId": 8, "developer": 2, "mobile": None, "smsMsg": msg}
        for mobile in phones:
            params["mobile"] = mobile
            requests.get(url, params=params)
    except Exception as e:
        if logger:
            logger.error("send sms exception")
            logger.exception(e)
        else:
            print("send sms exception")
            print(e)


def send_dingding(msg, token=None, logger=None):
    """
        钉钉告警
    """
    try:
        url = "https://oapi.dingtalk.com/robot/send?access_token=%s" % token
        params = {
            "msgtype": "text",
            "text": {
                "content": msg
            },
        }
        res = requests.post(url=url, json=params)
    except Exception as e:
        if logger:
            logger.error("send DingDing exception")
            logger.exception(e)
        else:
            print("send DingDing exception")
            print(e)


def monitor(types=None, msg='', project='气象工程项目', business='监控', token='', logger=None):
    if types is None:
        types = ['ding']
    now = datetime.datetime.now().strftime("%Y.%m.%d %H:%M:%S")
    hostname = socket.gethostname()
    # business = unicode(business.decode('utf8')) if type(business) == str else business
    # msg = unicode(msg.decode('utf8')) if type(msg) == str else msg
    msg = "【%s-%s@%s】：%s [%s]" % (project, business, hostname, msg, now)
    for t in types:
        if 'ding' == t:
            # send_wechat(msg)
            send_dingding(msg, token=token, logger=logger)
    if logger:
        logger.info(msg)
    else:
        print(msg)


if __name__ == "__main__":
    monitor(types=['ding'], msg='测试')
    send_dingding("测试", '7f34fda33c3aae2baa5d26f089f8bcd61fece808cd33c7887578c8f7af4abd99')
