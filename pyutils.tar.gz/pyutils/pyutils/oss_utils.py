#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

author:     meng.xiang
date:       2018-12-12
description:
"""

import os
from itertools import islice
from time import time

import gevent
import oss2
from gevent import monkey
from gevent.pool import Pool


class OssUtils(object):
    def __init__(self, **kawrgs):
        # default connection pool size
        # the pool size mast bg or eq than put&get thread number.
        """
        init function
        :param public_net: use public or aliyun private net.
        :param max_conn_pool: max num of threads
        """

        self.max_conn_pool = kawrgs.get("max_conn_pool", 10)
        self.access_key_id = kawrgs.get("access_key_id", None)
        assert self.access_key_id
        self.access_key_secret = kawrgs.get("access_key_secret", None)
        assert self.access_key_secret
        self.bucket_name = kawrgs.get("bucket_name", "mojimeteo")
        # public net like bj29 use this.
        # DO NOT USE THIS ADDRESS TO DOWNLOAD.
        self.endpoint = kawrgs.get("oss_endpoint", "vpc100-oss-cn-beijing.aliyuncs.com")

        self.bucket = oss2.Bucket(oss2.Auth(self.access_key_id, self.access_key_secret), self.endpoint,
                                  self.bucket_name)
        self.greenlet_pool = Pool(self.max_conn_pool)

    def get_obj(self, key, dst, use_resume=True, part_size=(20 * 1024 * 1024), num_threads=4):
        """
        get files from oss,
        :param key: oss key
        :param dst: The path to save obj.
        :return obj save path at last
        """
        if key.startswith('/'):
            key = key[1:]

        try:
            if use_resume:
                oss2.resumable_download(self.bucket, key, dst,
                                        store=oss2.ResumableDownloadStore(root='/tmp'),
                                        multiget_threshold=20 * 1024 * 1024,
                                        part_size=part_size,
                                        num_threads=num_threads)
            else:
                self.bucket.get_object_to_file(key, dst)
            return dst
        except Exception as ex:
            print(ex)
            return None

    def put_obj(self, key, src, use_resume=True, part_size=(20 * 1024 * 1024), num_threads=4):
        """
        put file to oss
        :param key: 远程地址
        :param src: 本地地址
        """
        # use resume
        try:
            if use_resume:
                res = oss2.resumable_upload(self.bucket, key, src,
                                            store=oss2.ResumableStore(root='/tmp'),
                                            multipart_threshold=100 * 1024,
                                            part_size=part_size,
                                            num_threads=num_threads)
            else:
                res = self.bucket.put_object_from_file(key, src)
        except Exception as ex:
            print(ex)


    def exists(self, key):
        """
        judge if the key exists
        :param key:
        :return:
        """
        return self.bucket.object_exists(key)

    def copy_obj(self, src_key, dst_key):
        """
        copy obj from src_key to dst_key
        :param key:
        :return:
        """
        return self.bucket.copy_object(self.bucket_name, src_key, dst_key)

    def list_obj(self, prefix='', delimiter='/', max_count=1000):
        """
        return a iterator in bucket
        :param prefix:
        :param max_count:
        :return:
        """
        return islice(oss2.ObjectIterator(self.bucket, delimiter=delimiter, prefix=prefix), max_count)

    def get_objs(self, src_root, dst_root):
        """
        get objs in oss
        """
        monkey.patch_all()
        if src_root.startswith('/'):
            src_root = src_root[1:]
        if not src_root.endswith('/'):
            src_root += '/'

        # make local dir if not exist
        def _touch_dir(path):
            result = False
            try:
                path = path.strip().rstrip("\\")
                if not os.path.exists(path):
                    os.makedirs(path)
                    result = True
                else:
                    result = True
            except:
                result = False
            return result

        _touch_dir(dst_root)

        def _get_objs(key):
            for obj in self.list_obj(key):
                # remove prefix of src_root
                _rel_path = obj.key[obj.key.index(src_root) + len(src_root):]
                local_obj = os.path.join(dst_root, _rel_path)
                if obj.is_prefix():  # directory
                    _touch_dir(local_obj)
                    _get_objs(obj.key)
                else:  # file
                    self.greenlet_pool.add(gevent.spawn(self.get_obj, obj.key, local_obj, False))
                    # oss_logger.info('file: %s->%s' % (obj.key, local_obj))

        _get_objs(src_root)
        self.greenlet_pool.join()

    def put_objs(self, src_root, dst_root):
        # patch all io
        monkey.patch_all()
        if dst_root.startswith('/'):
            dst_root = dst_root[1:]

        def _put_objs(_rel_path):
            local_path = os.path.join(src_root, _rel_path)
            filelist = os.listdir(local_path)
            for filename in filelist:
                oss_path = os.path.join(dst_root, _rel_path)
                key = os.path.join(oss_path, filename)
                local_obj = os.path.join(local_path, filename)
                _rel_path_obj = os.path.join(_rel_path, filename)
                if os.path.isdir(local_obj):
                    _put_objs(_rel_path_obj)
                else:
                    self.greenlet_pool.add(gevent.spawn(self.put_obj, key, local_obj, False))

        _put_objs('')
        self.greenlet_pool.join()


if __name__ == '__main__':
    oss = OssUtils(**{"access_key_id": "LTAIipB2qbeW3V99", "access_key_secret": "Dtyx9XKvFdQvmniSlns18j7lXpmA03",
             "bucket_name": "mojimeteo", "oss_endpoint": "oss-cn-beijing.aliyuncs.com"})
    # img_src = 'test'
    # s = timer()
    # OssUtils().put_obj(img_src, img_src, use_resume=False)
    # e = timer()
    # print '200MB上传单线程耗时%s' % (e - s)
    # s = timer()
    # OssUtils().put_obj(img_src, img_src)
    # e = timer()
    # print '200MB上传4线程耗时%s' % (e - s)
    # s = timer()
    # OssUtils().get_obj(img_src, img_src, use_resume=False)
    # e = timer()
    # print '200MB下载单线程耗时%s' % (e - s)
    # s = timer()
    # OssUtils().get_obj(img_src, img_src)
    # e = timer()
    # print '200MB下载4线程耗时%s' % (e - s)

    # for o in oss.list_obj(prefix=''):
    #     # if is_prefix is True,this obj is a dir
    #     print '%s:%s' % (o.key, o.is_prefix())

    ## put many obj to oss
    # s = time()
    # oss.put_objs('./test', '/test/test')
    # oss.put_objs('./test', 'sub_dir')
    # e = time()
    # print('2000MB下载10协程耗时%s' % (e - s))
    ## get many obj from oss
    # oss.get_objs('test/test', './dir_test')
    s = time()
    print("begin...")
    oss.put_obj("test/redis.conf", "/Users/tao.zhang/redis.conf")
    e = time()
    print('耗时%s' % (e - s))