import sys

import datetime
import time
from datetime import date


def gethour():
    return time.strftime("%H", time.localtime(getTimeStamp()))


def getfixedhour(fixhours, fixdays=0):
    return time.strftime("%H", time.localtime(getfixedTimeStamp(fixhours, fixdays)))


def getfixeddate(fixhours, fixdays=0):
    return time.strftime("%Y-%m-%d", time.localtime(getfixedTimeStamp(fixhours, fixdays)))


def gettime():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(getTimeStamp()))


def getfixedtime(format="%Y-%m-%d %H:%M:%S", fixhours=0, fixdays=0):
    return time.strftime(format, time.localtime(getfixedTimeStamp(fixhours, fixdays)))


def getTimeStamp():
    return int(time.time())


def getfixedTimeStamp(fixhours, fixdays=0):
    return int(time.time() + 3600 * fixhours + 86400 * fixdays)


def getWeekday():
    return time.strftime("%A", time.localtime(getTimeStamp()))


def getfixedWeekday(fixhours, fixdays=0):
    return time.strftime("%A", time.localtime(getfixedTimeStamp(fixhours, fixdays)))


# 计算时间差
def timediff(timestart, timestop):
    t = (timestop - timestart)
    time_day = t.days
    s_time = t.seconds
    ms_time = t.microseconds / 1000000
    usedtime = int(s_time + ms_time)
    time_hour = usedtime / 60 / 60
    time_minute = (usedtime - time_hour * 3600) / 60
    time_second = usedtime - time_hour * 3600 - time_minute * 60
    time_micsecond = (t.microseconds - t.microseconds / 1000000) / 1000
    retstr = "耗时%d天%d小时%d分%d秒%d毫秒" % (time_day, time_hour, time_minute, time_second, time_micsecond)
    return retstr


# string to timestruct
def stringToTimeStruct(string, format='%Y-%m-%d %H:%M:%S'):
    """format: 所传递的string格式"""
    return time.strptime(string, format)


# string to timestamp
def stringToTimestamp(string, format='%Y-%m-%d %H:%M:%S'):
    """format: 所传递的string格式"""
    return time.mktime(stringToTimeStruct(string, format))


# string to datetime
def stringToDatetime(string, format='%Y-%m-%d %H:%M:%S'):
    """format: 所传递的string格式"""
    return datetime.datetime.fromtimestamp(stringToTimestamp(string, format))


# datetime to timestamp
def datetimeToTimestamp(datetime, type='second'):
    if type == 'millisecond':
        return int(time.mktime(datetime.timetuple()) * 1000)
    return int(time.mktime(datetime.timetuple()))


# datetime to string
def datetimeToString(datetime, format='%Y-%m-%d %H:%M:%S'):
    return time.strftime(format, time.localtime(datetimeToTimestamp(datetime)))


# timestamp to string
def timestampToString(timestamp, formats='%Y-%m-%d %H:%M:%S'):
    return time.strftime(formats, time.localtime(timestamp))


# delay datetime by days
def dateDelayByDay(string, int):
    return datetimeToString(stringToDatetime(string) + datetime.timedelta(int))


# delay datetime by hours
def dateDelayByHour(string, int):
    return datetimeToString(stringToDatetime(string) + datetime.timedelta(hours=int))


# set datetime hour
def dateSetHour(string, int):
    return datetimeToString(stringToDatetime(string).replace(hour=int))


# get now time by format
def getNowStrTime(format="%Y-%m-%d %H:%M:%S"):
    return time.strftime(format, time.localtime(time.time()))


def getToday():
    return date.today()


def getdate():
    return time.strftime("%Y-%m-%d", time.localtime(getTimeStamp()))


def datetime_to_millisecond(dt):
    return time.mktime(dt.timetuple()) * 1000


def string_to_millisecond(dt):
    return time.mktime((datetime.datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')).timetuple()) * 1000


def millisecond_to_datetime(timestamp, convert_to_utc=True):
    if isinstance(timestamp, (int, long, float)):
        timestamp = timestamp / 1000
        dt = datetime.datetime.utcfromtimestamp(timestamp)
        if convert_to_utc:
            dt = dt + datetime.timedelta(hours=8)
        return dt
    return None


def is_outdate(timestamp, millisecond=24 * 3600 * 1000):
    if timestamp < (time.time() * 1000 - millisecond):
        return True
    return False


def get_now_datetime(formats='%Y-%m-%d %H:%M:%S'):
    n = int(time.time())
    return time.strftime(formats, time.localtime(n))


def timediff_millisecond(standard, diff):
    ft = (standard - diff) / 1000
    tt = standard / 1000
    return {'from': long(ft), 'to': long(tt)} if sys.version[0] < '3' else {'from': int(ft), 'to': int(tt)}


def millisecond_to_datetime(timestamp, convert_to_utc=True):
    if isinstance(timestamp, (int, long, float)):
        timestamp = timestamp / 1000
        dt = datetime.datetime.utcfromtimestamp(timestamp)
        if convert_to_utc:
            dt = dt + datetime.timedelta(hours=8)
        return dt
    return None
